/* Storyloom AI Presentation — template deck generator (v0.2).
   Builds lorem-ipsum template decks for each presentation type with pptxgenjs.
   Runs in Node (require) and in the browser (window.CXDeck). Storyloom Design System tokens only. */
(function (root) {
  "use strict";

  const C = {
    bg: "F4F4F2", surface: "FFFFFF", sunken: "ECECEA", text: "222731", text2: "63666A",
    petrol: "2E4AED", tileBg: "EEF0FE", petrolDark: "1628A3", onPetrol: "D6DBFC", citron: "D6DBFC", border: "D9D9D6", inverse: "000075", onInverse: "D6DBFC",
    okFg: "007A2C", okBg: "E5F7EC", warnFg: "A84600", warnBg: "FFF0E5", errFg: "B00021", errBg: "FDE6EA", infoFg: "1628A3", infoBg: "EEF0FE",
    dv: ["2E4AED", "000075", "E56A54", "AA0061", "00B140", "97A3F5"],
    dvText: ["2E4AED", "000075", "B0412D", "AA0061", "007A2C", "1628A3"], /* text-safe (4.5:1+) versions of dv for labels and numbers */
  };
  /* Key names kept for continuity: petrol = Royal blue (action, emphasis), citron = Pale lavender (the one highlight), inverse = Deep navy (title and section grounds). */
  const F = { disp: "Bricolage Grotesque", body: "Hanken Grotesk", mono: "IBM Plex Mono" };
  const T = { h1: 28, display: 42, h4: 15, body: 13.5, label: 10.5, code: 10 };
  /* Spacing grid ("moderate" whitespace): 0.75 in side margins, 0.3 in gaps, 0.4 in card padding,
     one-line titles, content area 1.85 to 6.3 in, source line 6.55 in, footer 7.0 in. */
  const W = 13.333, M = 0.75, CW = W - 2 * M, Y0 = 1.85, Y1 = 6.3, CH = Y1 - Y0, G = 0.3, P = 0.4;
  const colW = (n, g = G) => (CW - g * (n - 1)) / n, colX = (i, n, g = G) => M + i * (colW(n, g) + g);

  /* ---------- lorem ---------- */
  const LW = ("lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum curabitur pretium tincidunt lacus nulla gravida orci a odio nullam varius turpis et commodo pharetra est eros bibendum elit nec luctus magna felis sollicitudin mauris integer in mauris eu nibh euismod gravida").split(" ");
  function lorem(n, seed = 0, end = ".") {
    const w = []; for (let i = 0; i < n; i++) w.push(LW[(seed * 7 + i) % LW.length]);
    const s = w.join(" "); return s.charAt(0).toUpperCase() + s.slice(1) + end;
  }
  const words = (n, seed) => lorem(n, seed, "");

  /* ---------- deck definitions ---------- */
  const EXP_BASE = (mode, resultsR, resultsIds) => [
    ["execSummary", "SLD-EXEC-SUMMARY-01", "Experiment overview"],
    ["insight", "SLD-INSIGHT-01", "Problem / opportunity"],
    ["statement", "SLD-STATEMENT-01", "Hypothesis", { hypothesis: true }],
    ["process", "SLD-PROCESS-01", "Experiment design"],
    ["variants", "SLD-VARIANTS-01", "Variants / experience"],
    [resultsR, "SLD-KPI-TREND-01", "Results · " + mode, { ids: resultsIds }],
    ["threeCol", "SLD-3COL-01", "What we learned", { label: "LEARNING", icons: ["lightbulb", "flask", "target"] }],
    ["twoCol", "SLD-2COL-01", "Implications"],
    ["nextSteps", "SLD-NEXT-STEPS-01", "Next steps"],
  ];
  const DECKS = [
    { key: "performance", type: "TPL-PERFORMANCE-01", story: "STORY-PERF-01", name: "Performance Readout", file: "Template_Performance_Readout_v1.pptx",
      slides: [
        ["execSummary", "SLD-EXEC-SUMMARY-01", "Executive summary"],
        ["kpiGrid", "SLD-KPI-GRID-01", "Performance at a glance"],
        ["kpiTrend", "SLD-KPI-TREND-01", "KPI / metric overview"],
        ["chartFocus", "SLD-CHART-FOCUS-01", "Trend over time"],
        ["threeCol", "SLD-3COL-01", "Key drivers", { label: "DRIVER", icons: ["trendUp", "users", "clock"] }],
        ["matrix", "SLD-MATRIX-01", "Areas of opportunity"],
        ["recommend", "SLD-RECOMMEND-01", "Recommendations / next steps"],
      ] },
    { key: "experiment-ab", type: "TPL-EXPERIMENT-01", story: "STORY-EXP-01", name: "Experiment Readout", mode: "Quantitative / A-B", modeIds: "VIZ-VARIANTS-01, VIZ-KPI-01, VIZ-BAR-01", file: "Template_Experiment_Readout_AB_v1.pptx",
      slides: EXP_BASE("Quantitative A/B", "resultsAB", "VIZ-VARIANTS-01 · VIZ-KPI-01 · VIZ-BAR-01") },
    { key: "experiment-behavioral", type: "TPL-EXPERIMENT-01", story: "STORY-EXP-01", name: "Experiment Readout", mode: "Behavioral", modeIds: "VIZ-FUNNEL-01, VIZ-TREND-01", file: "Template_Experiment_Readout_Behavioral_v1.pptx",
      slides: EXP_BASE("Behavioral", "resultsBehavioral", "VIZ-FUNNEL-01 · VIZ-TREND-01") },
    { key: "experiment-qualitative", type: "TPL-EXPERIMENT-01", story: "STORY-EXP-01", name: "Experiment Readout", mode: "Qualitative / feedback", modeIds: "CMP-QUOTE-01, VIZ-CLUSTER-01", file: "Template_Experiment_Readout_Qualitative_v1.pptx",
      slides: EXP_BASE("Qualitative", "resultsQual", "CMP-QUOTE-01 · VIZ-CLUSTER-01") },
    { key: "experiment-mixed", type: "TPL-EXPERIMENT-01", story: "STORY-EXP-01", name: "Experiment Readout", mode: "Mixed", modeIds: "SLD-2COL-01: metric left, quote right", file: "Template_Experiment_Readout_Mixed_v1.pptx",
      slides: EXP_BASE("Mixed", "resultsMixed", "SLD-2COL-01 · metric left, quote right") },
    { key: "campaign", type: "TPL-CAMPAIGN-01", story: "STORY-CONCEPT-01", name: "Campaign / Concept", file: "Template_Campaign_Concept_v1.pptx",
      slides: [
        ["statement", "SLD-STATEMENT-01", "Context"],
        ["insight", "SLD-INSIGHT-01", "Opportunity"],
        ["persona", "SLD-PERSONA-01", "Audience / customer"],
        ["quote", "SLD-QUOTE-01", "Insight"],
        ["deviceHero", "SLD-DEVICE-HERO-01", "Concept"],
        ["journeyFuture", "SLD-JOURNEY-01", "Experience / journey"],
        ["messaging", "SLD-MESSAGING-01", "Key touchpoints"],
        ["deviceTrio", "SLD-DEVICE-TRIO-01", "Creative direction"],
        ["twoCol", "SLD-2COL-01", "Supporting evidence"],
        ["kpiGrid", "SLD-KPI-GRID-01", "Expected impact", { projected: true }],
        ["nextSteps", "SLD-NEXT-STEPS-01", "Next steps"],
      ] },
    { key: "journey", type: "TPL-JOURNEY-01", story: "STORY-JOURNEY-01", name: "Journey Presentation", file: "Template_Journey_Presentation_v1.pptx",
      slides: [
        ["execSummary", "SLD-EXEC-SUMMARY-01", "Journey overview"],
        ["persona", "SLD-PERSONA-01", "Customer / audience"],
        ["journeyStages", "SLD-JOURNEY-01", "Journey stages"],
        ["journeyCurrent", "SLD-JOURNEY-01", "Current-state experience"],
        ["threeCol", "SLD-3COL-01", "Pain points / friction", { label: "PAIN POINT", icons: ["alert", "clock", "users"] }],
        ["quote", "SLD-QUOTE-01", "Needs / insights"],
        ["threeCol", "SLD-3COL-01", "Opportunities", { label: "OPPORTUNITY", icons: ["lightbulb", "target", "compass"] }],
        ["journeyFuture", "SLD-JOURNEY-01", "Future-state journey"],
        ["threeCol", "SLD-3COL-01", "Experience principles", { label: "PRINCIPLE", icons: ["heart", "shield", "check"] }],
        ["matrix", "SLD-MATRIX-01", "Priority opportunities"],
        ["nextSteps", "SLD-NEXT-STEPS-01", "Next steps"],
      ] },
  ];

  const FRAMES = {
    "IPHONE-01": { file: "A-DEV-IPHONE-01_iphone-15-pro_portrait_transparent.png", px: [664, 1328], area: [4.97, 2.18, 90.21, 95.63] },
    "IPAD-01": { file: "A-DEV-IPAD-01_ipad-pro_portrait_transparent.png", px: [1803, 2353], area: [4.22, 3.27, 91.51, 93.54] },
    "LAPTOP-01": { file: "A-DEV-LAPTOP-01_macbook-air_front_transparent.png", px: [2016, 1136], area: [12.3, 5.81, 75.5, 84.15] },
  };
  const ICON_NAMES = ["alert", "users", "chart", "target", "clock", "message", "check", "trendUp", "trendDown", "flask", "lightbulb", "map", "flag", "layers", "shield", "lock", "phone", "user", "compass", "heart"];
  const ICON_COLORS = ["FFFFFF", "2E4AED", "007A2C"];

  /* ---------- builder ---------- */
  function build(PptxGen, key, A) {
    const deck = DECKS.find(d => d.key === key);
    if (!deck) throw new Error("Unknown deck " + key);
    const pres = new PptxGen();
    pres.layout = "LAYOUT_WIDE";
    pres.title = `${deck.name}${deck.mode ? " · " + deck.mode : ""} — template`;
    pres.author = "Storyloom AI";
    const S = pres.shapes;
    const total = deck.slides.length + 2;
    const typeLabel = deck.name + (deck.mode ? " · " + deck.mode : "");

    const tx = (s, text, o) => s.addText(text, Object.assign({ isTextBox: true, margin: 0, fontFace: F.body, color: C.text, fontSize: T.body, valign: "top" }, o));
    const rr = (s, x, y, w, h, fill, line, r = 0.12, lw = 0.75) => s.addShape(S.ROUNDED_RECTANGLE, { x, y, w, h, fill: { color: fill }, line: { color: line || fill, width: lw }, rectRadius: r });
    const card = (s, x, y, w, h, fill = C.surface) => rr(s, x, y, w, h, fill, fill === C.surface ? C.border : fill);
    const oval = (s, x, y, d, fill) => s.addShape(S.OVAL, { x, y, w: d, h: d, fill: { color: fill }, line: { color: fill } });
    const icon = (s, name, color, x, y, d) => { const data = A.icon(name, color); if (data) s.addImage({ data, x, y, w: d, h: d }); };
    /* Rounded icon variant (ICN-*-RD): 40px tile, radius-lg, selected-bg fill, petrol icon. Default on slides. */
    const tile = (s, name, x, y, d) => { rr(s, x, y, d, d, C.tileBg, C.tileBg, d * 0.3); icon(s, name, C.petrol, x + d * 0.2, y + d * 0.2, d * 0.6); };
    const num = (s, n, x, y, d, fill = C.petrol) => { oval(s, x, y, d, fill); tx(s, String(n), { x, y, w: d, h: d, fontSize: T.label, bold: true, color: "FFFFFF", align: "center", valign: "middle" }); };
    const pill = (s, text, x, y, w, fill, color, h = 0.34) => { rr(s, x, y, w, h, fill, fill, 0.08); tx(s, text, { x, y, w, h, fontSize: T.label, bold: true, color, align: "center", valign: "middle" }); };
    const label = (s, text, x, y, w, color = C.text2) => tx(s, text, { x, y, w, h: 0.3, fontSize: T.label, bold: true, color, charSpacing: 1 });
    const cap = t => t.replace(/^./, c => c.toUpperCase());

    function header(s, kicker, title) {
      tx(s, kicker.toUpperCase(), { x: M, y: 0.55, w: 9.4, h: 0.3, fontSize: T.label, bold: true, color: C.petrol, charSpacing: 1 });
      tx(s, title, { x: M, y: 0.88, w: CW, h: 0.62, fontFace: F.disp, fontSize: T.h1, bold: true, lineSpacingMultiple: 0.95 });
    }
    function footer(s, n, id) {
      tx(s, `[Project name] · ${typeLabel}`, { x: M, y: 7.0, w: 4.8, h: 0.28, fontSize: T.label, color: C.text2 });
      tx(s, id, { x: 5.4, y: 7.0, w: W - M - 0.85 - 5.4, h: 0.28, fontFace: F.mono, fontSize: T.code, color: C.text2, align: "right" });
      tx(s, String(n).padStart(2, "0") + " / " + total, { x: W - M - 0.7, y: 7.0, w: 0.7, h: 0.28, fontSize: T.label, color: C.text2, align: "right" });
    }
    function base(n, kicker, id, title) { const s = pres.addSlide(); s.background = { color: C.bg }; header(s, kicker, title); footer(s, n, id); return s; }
    function phone(s, frameKey, x, y, h, lab) {
      const f = FRAMES[frameKey]; const w = h * f.px[0] / f.px[1];
      const sx = x + w * f.area[0] / 100, sy = y + h * f.area[1] / 100, sw = w * f.area[2] / 100, sh = h * f.area[3] / 100;
      rr(s, sx, sy, sw, sh, C.sunken, C.sunken, frameKey === "LAPTOP-01" ? 0.04 : Math.min(0.3, sw * 0.14));
      tx(s, [{ text: lab, options: { bold: true, breakLine: true } }, { text: "Screenshot goes here", options: { fontSize: T.label, color: C.text2 } }],
        { x: sx + 0.1, y: sy + sh / 2 - 0.3, w: sw - 0.2, h: 0.6, fontSize: T.body, align: "center", valign: "middle" });
      const data = A.frame(frameKey); if (data) s.addImage({ data, x, y, w, h });
      return w;
    }
    function callout(s, n, title, body, x, y, w, color = C.petrol) {
      num(s, n, x, y, 0.36, color);
      tx(s, title, { x: x + 0.56, y: y - 0.02, w: w - 0.56, h: 0.32, fontFace: F.disp, fontSize: T.h4, bold: true });
      tx(s, body, { x: x + 0.56, y: y + 0.36, w: w - 0.56, h: 0.7, fontSize: T.body, color: C.text2 });
    }
    const chartBase = () => ({ fontFace: F.body, catAxisLabelFontFace: F.body, valAxisLabelFontFace: F.body, catAxisLabelColor: C.text2, valAxisLabelColor: C.text2, catAxisLabelFontSize: 10, valAxisLabelFontSize: 10, valGridLine: { color: C.border, size: 0.5 }, catGridLine: { style: "none" }, catAxisLineShow: false, valAxisLineShow: false, dataLabelFontFace: F.body, dataLabelFontSize: 10, dataLabelColor: C.text });

    /* journey grid: row labels on the left, five stage columns */
    const STG = ["Stage 1", "Stage 2", "Stage 3", "Stage 4", "Stage 5"];
    const GX = M + 1.6, GW = W - M - GX, SG = 0.2, SW = (GW - SG * 4) / 5, sx = i => GX + i * (SW + SG);
    const rowLabel = (s, t, y, h) => tx(s, t, { x: M, y, w: 1.4, h, fontSize: T.label, bold: true, color: C.text2, valign: "middle" });
    const stageRow = (s, subs, h = 0.6) => STG.forEach((st, i) => { rr(s, sx(i), Y0, SW, h, C.petrol, C.petrol, 0.08); tx(s, [{ text: st + " · " + words(1, i + 3), options: { bold: true, breakLine: !!subs } }].concat(subs ? [{ text: subs[i], options: { fontSize: T.label, color: C.onPetrol } }] : []), { x: sx(i) + 0.16, y: Y0, w: SW - 0.24, h, color: "FFFFFF", fontSize: T.label + 1, valign: "middle" }); });
    const cells = (s, y, h, fill, line, seed, n = 6, color = C.text) => STG.forEach((_, i) => { rr(s, sx(i), y, SW, h, fill, line, 0.08); tx(s, lorem(n, seed + i), { x: sx(i) + 0.16, y: y + 0.14, w: SW - 0.32, h: h - 0.22, fontSize: T.label + 1, color }); });
    function emotion(s, y, h, scores, labels, color) {
      rr(s, GX, y, GW, h, C.surface, C.border, 0.1);
      const pts = scores.map((v, i) => ({ x: sx(i) + SW / 2, y: y + 0.24 + (1 - v) * (h - 0.74) }));
      for (let i = 0; i < pts.length - 1; i++) { const a = pts[i], b = pts[i + 1]; s.addShape(S.LINE, { x: a.x, y: Math.min(a.y, b.y), w: b.x - a.x, h: Math.max(Math.abs(b.y - a.y), 0.001), flipV: b.y < a.y, line: { color, width: 2 } }); }
      pts.forEach((p, i) => { s.addShape(S.OVAL, { x: p.x - 0.09, y: p.y - 0.09, w: 0.18, h: 0.18, fill: { color }, line: { color: "FFFFFF", width: 1.5 } }); tx(s, labels[i], { x: sx(i), y: p.y + 0.13, w: SW, h: 0.26, fontSize: T.label, color: C.text2, align: "center" }); });
    }

    /* ---------- slide renderers (all inside the content area Y0..Y1) ---------- */
    const R = {
      execSummary(s) {
        const pts = [["CONTEXT", "42%", "alert"], ["FINDING", "3 of 5", "users"], ["IMPACT", "+18 pts", "chart"]];
        const cw = colW(3), ch = 2.75;
        pts.forEach((p, i) => { const x = colX(i, 3), y = Y0; card(s, x, y, cw, ch);
          tile(s, p[2], x + P, y + P, 0.5);
          label(s, p[0], x + P + 0.65, y + P + 0.1, cw - 2 * P - 0.65);
          tx(s, p[1], { x: x + P, y: y + 1.05, w: cw - 2 * P, h: 0.8, fontFace: F.disp, fontSize: T.display, bold: true, color: C.petrol });
          tx(s, lorem(12, i + 2), { x: x + P, y: y + 1.9, w: cw - 2 * P, h: 0.7, color: C.text2 }); });
        const ay = Y0 + ch + G, ah = Y1 - ay - 0.15;
        rr(s, M, ay, CW, ah, C.inverse, C.inverse, 0.12);
        pill(s, "THE ASK", M + P, ay + (ah - 0.46) / 2, 1.3, C.citron, C.inverse, 0.46);
        tx(s, lorem(16, 9), { x: M + P + 1.6, y: ay, w: CW - 2 * P - 1.6, h: ah, fontSize: 16, color: "FFFFFF", valign: "middle" });
      },
      statement(s, o) {
        const bh = 2.95;
        rr(s, M, Y0, CW, bh, C.petrol, C.petrol, 0.14);
        if (o.hypothesis) pill(s, "HYPOTHESIS", M + 0.5, Y0 + 0.45, 1.7, C.citron, C.inverse);
        tx(s, o.hypothesis ? "We believe that " + words(8, 4).toLowerCase() + " will " + words(6, 12).toLowerCase() + "." : lorem(15, 5), { x: M + 0.5, y: o.hypothesis ? Y0 + 0.95 : Y0 + 0.4, w: CW - 1.0, h: o.hypothesis ? 1.65 : 2.15, fontFace: F.disp, fontSize: 28, bold: true, color: "FFFFFF", valign: "middle" });
        const cols = o.hypothesis ? [["WE'LL KNOW IT WORKED WHEN", lorem(10, 20)], ["PRIMARY METRIC", "Lorem ipsum rate, +2 pts or more"], ["GUARDRAIL", lorem(7, 30)]] : [["WHY NOW", lorem(10, 20)], ["WHAT'S CHANGED", lorem(10, 26)], ["WHAT'S AT STAKE", lorem(10, 33)]];
        const cy = Y0 + bh + 0.4;
        cols.forEach((c, i) => { const x = colX(i, 3); label(s, c[0], x, cy, colW(3)); tx(s, c[1], { x, y: cy + 0.32, w: colW(3), h: Y1 - cy - 0.32 }); });
      },
      kpiGrid(s, o) {
        const k = [["Lorem ipsum rate", "46%", "Up", "trendUp", "34% → 46% vs baseline"], ["Dolor sit time", "–18 days", "Down (better)", "trendDown", "41 → 23 days, median"], ["Amet steps", "5 → 2", "Down (better)", "trendDown", "Consectetur adipiscing"], ["Elit satisfaction", "4.5", "Up", "trendUp", "3.9 → 4.5 out of 5"]];
        const cw = colW(4), ch = 2.95;
        k.forEach((m, i) => { const x = colX(i, 4), y = Y0; card(s, x, y, cw, ch);
          tx(s, m[0], { x: x + P, y: y + P, w: cw - 2 * P, h: 0.32, bold: true, color: C.text2 });
          tx(s, m[1], { x: x + P, y: y + 0.9, w: cw - 2 * P, h: 0.8, fontFace: F.disp, fontSize: 26, bold: true, color: C.petrol, valign: "middle" });
          rr(s, x + P, y + 1.85, 1.9, 0.38, C.okBg, C.okBg, 0.08); icon(s, m[3], C.okFg, x + P + 0.1, y + 1.92, 0.24);
          tx(s, m[2], { x: x + P + 0.42, y: y + 1.85, w: 1.45, h: 0.38, fontSize: T.label, bold: true, color: C.okFg, valign: "middle" });
          tx(s, m[4], { x: x + P, y: y + 2.38, w: cw - 2 * P, h: 0.4, fontSize: T.label + 1, color: C.text2 }); });
        const dy = Y0 + ch + G, dh = Y1 - dy - 0.1;
        card(s, M, dy, CW, dh, C.sunken);
        tx(s, [{ text: (o.projected ? "How we'll measure  " : "Definitions  "), options: { bold: true } }, { text: lorem(18, 14), options: { color: C.text2 } }], { x: M + P, y: dy, w: CW - 2 * P, h: dh, valign: "middle" });
      },
      kpiTrend(s) {
        const lw = 3.0, rw = 3.0, mx = M + lw + G, mw = CW - lw - rw - 2 * G, rx = mx + mw + G;
        card(s, M, Y0, lw, CH);
        label(s, "LOREM IPSUM RATE", M + P, Y0 + P, lw - 2 * P);
        tx(s, "46%", { x: M + P, y: Y0 + 0.8, w: lw - 2 * P, h: 0.95, fontFace: F.disp, fontSize: T.display, bold: true, color: C.petrol });
        rr(s, M + P, Y0 + 1.85, 1.75, 0.38, C.okBg, C.okBg, 0.08); icon(s, "trendUp", C.okFg, M + P + 0.1, Y0 + 1.92, 0.24);
        tx(s, "Up 6 pts", { x: M + P + 0.42, y: Y0 + 1.85, w: 1.3, h: 0.38, fontSize: T.label, bold: true, color: C.okFg, valign: "middle" });
        tx(s, [{ text: "Q3 2026 vs Q3 2025", options: { bold: true, breakLine: true } }, { text: lorem(9, 8) }], { x: M + P, y: Y0 + 2.5, w: lw - 2 * P, h: 1.6, color: C.text2, paraSpaceAfter: 4 });
        card(s, mx, Y0, mw, CH);
        tx(s, "Monthly lorem ipsum rate, %", { x: mx + P, y: Y0 + P - 0.05, w: mw - 2 * P, h: 0.3, fontSize: T.label, bold: true, color: C.text2 });
        s.addChart(pres.charts.LINE, [{ name: "Rate", labels: ["Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep"], values: [38, 39, 38, 40, 41, 40, 42, 43, 43, 44, 45, 46] }],
          Object.assign(chartBase(), { x: mx + 0.2, y: Y0 + 0.75, w: mw - 0.4, h: CH - 1.0, chartColors: [C.petrol], lineSize: 2.5, lineDataSymbol: "circle", lineDataSymbolSize: 6, showLegend: false, valAxisMinVal: 30, valAxisMaxVal: 50 }));
        rr(s, rx, Y0, rw, CH, C.petrol, C.petrol, 0.12);
        label(s, "INSIGHT", rx + P, Y0 + P, rw - 2 * P, C.onPetrol);
        tx(s, lorem(9, 16), { x: rx + P, y: Y0 + 0.8, w: rw - 2 * P, h: 1.5, fontFace: F.disp, fontSize: 17, bold: true, color: "FFFFFF" });
        label(s, "IMPLICATION", rx + P, Y0 + 2.55, rw - 2 * P, C.onPetrol);
        tx(s, lorem(10, 22), { x: rx + P, y: Y0 + 2.9, w: rw - 2 * P, h: 1.2, color: "FFFFFF" });
      },
      chartFocus(s) {
        const rw = 3.4, lw = CW - rw - G, rx = M + lw + G;
        card(s, M, Y0, lw, CH);
        tx(s, "Lorem ipsum volume by quarter, thousands", { x: M + P, y: Y0 + P - 0.05, w: lw - 2 * P, h: 0.3, fontSize: T.label, bold: true, color: C.text2 });
        s.addChart(pres.charts.BAR, [{ name: "Volume", labels: ["Q4 '24", "Q1 '25", "Q2 '25", "Q3 '25", "Q4 '25", "Q1 '26", "Q2 '26", "Q3 '26"], values: [112, 118, 121, 119, 131, 138, 142, 155] }],
          Object.assign(chartBase(), { x: M + 0.25, y: Y0 + 0.75, w: lw - 0.5, h: CH - 1.0, barDir: "col", chartColors: [C.petrol], showValue: true, dataLabelPosition: "outEnd", showLegend: false, barGapWidthPct: 70 }));
        rr(s, rx, Y0, rw, CH, C.surface, C.border, 0.12);
        tx(s, "+38%", { x: rx + P, y: Y0 + P, w: rw - 2 * P, h: 0.9, fontFace: F.disp, fontSize: T.display, bold: true, color: C.petrol });
        tx(s, "since Q4 2024", { x: rx + P, y: Y0 + 1.3, w: rw - 2 * P, h: 0.3, fontSize: T.label, color: C.text2 });
        pill(s, "TAKEAWAY", rx + P, Y0 + 1.9, 1.4, C.citron, C.inverse);
        tx(s, lorem(16, 11), { x: rx + P, y: Y0 + 2.45, w: rw - 2 * P, h: 1.6 });
      },
      threeCol(s, o) {
        const cw = colW(3);
        [0, 1, 2].forEach(i => { const x = colX(i, 3), y = Y0; card(s, x, y, cw, CH);
          tile(s, o.icons[i], x + P, y + P, 0.64);
          label(s, `${o.label} ${i + 1}`, x + P, y + 1.3, cw - 2 * P);
          tx(s, cap(words(4, i * 5 + 3 + (o.seed || 0) * 11)), { x: x + P, y: y + 1.65, w: cw - 2 * P, h: 0.8, fontFace: F.disp, fontSize: 19, bold: true });
          tx(s, lorem(20, i * 4 + 6 + (o.seed || 0) * 13), { x: x + P, y: y + 2.55, w: cw - 2 * P, h: CH - 2.55 - P, color: C.text2 }); });
      },
      matrix(s) {
        const x0 = M + 0.5, y0 = Y0, w = 6.6, h = CH - 0.4;
        card(s, x0, y0, w, h);
        rr(s, x0 + 0.02, y0 + 0.02, w / 2 - 0.02, h / 2 - 0.02, C.okBg, C.okBg, 0.1);
        s.addShape(S.LINE, { x: x0 + w / 2, y: y0, w: 0, h, line: { color: C.border, width: 1 } });
        s.addShape(S.LINE, { x: x0, y: y0 + h / 2, w, h: 0, line: { color: C.border, width: 1 } });
        [["Quick wins", 0, 0], ["Big bets", 1, 0], ["Fill-ins", 0, 1], ["Deprioritize", 1, 1]].forEach(([t, qx, qy]) => tx(s, t, { x: x0 + qx * w / 2 + 0.25, y: y0 + qy * h / 2 + 0.2, w: 2.5, h: 0.3, fontSize: T.label, bold: true, color: qx === 0 && qy === 0 ? C.okFg : C.text2 }));
        tx(s, "IMPACT ↑", { x: M - 0.15, y: y0 + h / 2 - 0.15, w: 0.7, h: 0.3, fontSize: T.label, bold: true, color: C.text2, rotate: 270 });
        tx(s, "EFFORT →", { x: x0 + w / 2 - 0.6, y: y0 + h + 0.1, w: 1.2, h: 0.3, fontSize: T.label, bold: true, color: C.text2, align: "center" });
        const dots = [[0.2, 0.22], [0.36, 0.36], [0.7, 0.2], [0.28, 0.72], [0.66, 0.64], [0.82, 0.82]];
        dots.forEach(([dx, dy], i) => num(s, i + 1, x0 + dx * w - 0.2, y0 + dy * h - 0.2, 0.4, i < 2 ? C.petrol : C.text2));
        const lx = x0 + w + 0.7, lw = W - M - lx, rh = (CH - 0.45) / dots.length;
        label(s, "OPPORTUNITIES", lx, Y0, lw);
        dots.forEach((_, i) => { const y = Y0 + 0.45 + i * rh; num(s, i + 1, lx, y + 0.03, 0.36, i < 2 ? C.petrol : C.text2); tx(s, [{ text: cap(words(4, i * 3 + 2)), options: { bold: true, breakLine: true } }, { text: words(5, i * 5 + 9), options: { color: C.text2, fontSize: T.label + 1 } }], { x: lx + 0.56, y, w: lw - 0.56, h: rh - 0.08 }); });
      },
      recommend(s) {
        const gap = 0.35, ch = (CH - 2 * gap) / 3;
        [0, 1, 2].forEach(i => { const y = Y0 + i * (ch + gap); card(s, M, y, CW, ch);
          num(s, i + 1, M + P, y + (ch - 0.46) / 2, 0.46);
          tx(s, cap(words(5, i * 4 + 2)), { x: M + 1.15, y: y + 0.26, w: CW - 1.15 - 3.2, h: 0.36, fontFace: F.disp, fontSize: 17, bold: true });
          tx(s, lorem(15, i * 6 + 7), { x: M + 1.15, y: y + 0.66, w: CW - 1.15 - 3.2, h: ch - 0.8, color: C.text2 });
          pill(s, "Evidence: slide " + String(i + 3).padStart(2, "0"), W - M - P - 2.3, y + (ch - 0.38) / 2, 2.3, C.sunken, C.text2, 0.38); });
      },
      insight(s) {
        const lw = 5.3, rx = M + lw + G, rw = W - M - rx, gap = 0.3, ch = (CH - 2 * gap) / 3;
        rr(s, M, Y0, lw, CH, C.petrol, C.petrol, 0.12);
        tile(s, "target", M + P, Y0 + P, 0.6);
        label(s, "INSIGHT", M + P, Y0 + 1.25, lw - 2 * P, C.onPetrol);
        tx(s, lorem(8, 3), { x: M + P, y: Y0 + 1.6, w: lw - 2 * P, h: 1.4, fontFace: F.disp, fontSize: 21, bold: true, color: "FFFFFF" });
        label(s, "IMPLICATION", M + P, Y0 + 3.2, lw - 2 * P, C.onPetrol);
        tx(s, lorem(12, 12), { x: M + P, y: Y0 + 3.55, w: lw - 2 * P, h: 0.8, color: "FFFFFF" });
        [["1 in 3", "Lorem · order data · n = 4,200"], ["62%", "Survey · online · n = 1,200"], ["5 steps", "Journey audit · 3 channels"]].forEach((e, i) => { const y = Y0 + i * (ch + gap); card(s, rx, y, rw, ch);
          tx(s, e[0], { x: rx + P, y: y + 0.18, w: 2.0, h: 0.7, fontFace: F.disp, fontSize: 30, bold: true, color: C.petrol, valign: "middle" });
          tx(s, lorem(6, i * 5 + 4), { x: rx + P + 2.2, y: y + 0.18, w: rw - 2 * P - 2.2, h: 0.7, bold: true, valign: "middle" });
          tx(s, "EVIDENCE  " + e[1], { x: rx + P, y: y + ch - 0.42, w: rw - 2 * P, h: 0.28, fontSize: T.label, color: C.text2 }); });
      },
      process(s) {
        const n = 5, x0 = M + 1.0, x1 = W - M - 1.0, step = (x1 - x0) / (n - 1), cy = Y0 + 0.55;
        s.addShape(S.LINE, { x: x0, y: cy, w: x1 - x0, h: 0, line: { color: C.border, width: 2 } });
        ["Recruit", "Randomize", "Expose", "Measure", "Decide"].forEach((t, i) => { const x = x0 + i * step; num(s, i + 1, x - 0.3, cy - 0.3, 0.6);
          tx(s, t, { x: x - 1.05, y: cy + 0.55, w: 2.1, h: 0.35, fontFace: F.disp, fontSize: T.h4, bold: true, align: "center" });
          tx(s, lorem(7, i * 3 + 5), { x: x - 1.05, y: cy + 0.95, w: 2.1, h: 0.9, fontSize: T.label + 1, color: C.text2, align: "center" }); });
        const fh = 1.35, fy = Y1 - fh;
        card(s, M, fy, CW, fh, C.sunken);
        const f = [["AUDIENCE", "n = 12,000"], ["SPLIT", "50 / 50"], ["DURATION", "4 weeks"], ["PRIMARY METRIC", "Lorem ipsum rate"], ["GUARDRAIL", "Dolor opt-out"]];
        const fw = (CW - 2 * P) / 5; f.forEach((d, i) => { const x = M + P + i * fw; label(s, d[0], x, fy + 0.32, fw - 0.2); tx(s, d[1], { x, y: fy + 0.65, w: fw - 0.2, h: 0.45, fontFace: F.disp, fontSize: 17, bold: true }); });
      },
      variants(s) {
        const names = [["Control", C.text2, "10.2%"], ["Variant A", C.dvText[0], "11.6%"], ["Variant B", C.dvText[1], "12.9%"]];
        const cw = colW(3), ph = 3.2, py = Y0 + 0.5;
        names.forEach((v, i) => { const x = colX(i, 3);
          pill(s, v[0], x, Y0, 1.6, C.surface, v[1]);
          const pw = phone(s, "IPHONE-01", x, py, ph, v[0]);
          const t0 = x + pw + 0.3, tw = cw - pw - 0.3;
          tx(s, lorem(6, i * 4 + 3), { x: t0, y: py + 0.1, w: tw, h: 1.2, color: C.text2 });
          tx(s, v[2], { x: t0, y: py + 1.55, w: tw, h: 0.6, fontFace: F.disp, fontSize: 26, bold: true, color: v[1] });
          tx(s, i === 0 ? "Baseline" : (i === 1 ? "+1.4 pts vs control" : "+2.7 pts vs control"), { x: t0, y: py + 2.15, w: tw, h: 0.3, fontSize: T.label, color: C.text2 }); });
        const by = py + ph + 0.3, bh = Y1 - by + 0.1;
        card(s, M, by, CW, bh, C.sunken);
        tx(s, [{ text: "What changed  ", options: { bold: true } }, { text: lorem(14, 18), options: { color: C.text2 } }], { x: M + P, y: by, w: CW - 2 * P, h: bh, valign: "middle" });
      },
      resultsAB(s) {
        const k = [["Control", "10.2%", "Baseline", C.text2], ["Variant A", "11.6%", "+1.4 pts", C.dvText[0]], ["Variant B · winner", "12.9%", "+2.7 pts", C.dvText[1]]];
        const lw = 3.4, gap = 0.3, ch = (CH - 2 * gap) / 3;
        k.forEach((m, i) => { const y = Y0 + i * (ch + gap); card(s, M, y, lw, ch);
          label(s, m[0].toUpperCase(), M + P, y + 0.25, lw - 2 * P, m[3]);
          tx(s, m[1], { x: M + P, y: y + 0.55, w: 1.6, h: 0.6, fontFace: F.disp, fontSize: 28, bold: true });
          tx(s, m[2], { x: M + P + 1.55, y: y + 0.66, w: lw - 2 * P - 1.55, h: 0.4, fontSize: T.label, bold: true, color: i === 2 ? C.okFg : C.text2 }); });
        const cx = M + lw + G, cw = W - M - cx, sh = 0.8, chh = CH - sh - G;
        card(s, cx, Y0, cw, chh);
        tx(s, "Conversion by variant, %", { x: cx + P, y: Y0 + P - 0.05, w: cw - 2 * P, h: 0.3, fontSize: T.label, bold: true, color: C.text2 });
        s.addChart(pres.charts.BAR, [{ name: "Conversion", labels: ["Control", "Variant A", "Variant B"], values: [10.2, 11.6, 12.9] }],
          Object.assign(chartBase(), { dataLabelFormatCode: "0.0", x: cx + 0.25, y: Y0 + 0.75, w: cw - 0.5, h: chh - 0.95, barDir: "bar", chartColors: [C.petrol], showValue: true, dataLabelPosition: "outEnd", showLegend: false, valAxisMinVal: 0, valAxisMaxVal: 15, barGapWidthPct: 80 }));
        card(s, cx, Y1 - sh, cw, sh, C.sunken);
        tx(s, [{ text: "Significance  ", options: { bold: true } }, { text: "p = 0.01 · 95% CI +1.1 to +4.3 pts · n = 12,000", options: { color: C.text2 } }], { x: cx + P, y: Y1 - sh, w: cw - 2 * P, h: sh, valign: "middle" });
      },
      resultsBehavioral(s) {
        const lw = 6.2, rx = M + lw + G, rw = W - M - rx, ih = 1.25, chh = CH - ih - G;
        card(s, M, Y0, lw, CH);
        tx(s, "Funnel: share of users reaching each step, %", { x: M + P, y: Y0 + P - 0.05, w: lw - 2 * P, h: 0.3, fontSize: T.label, bold: true, color: C.text2 });
        s.addChart(pres.charts.BAR, [{ name: "Control", labels: ["Opened", "Started", "Completed form", "Ordered", "Returned"], values: [100, 64, 41, 30, 22] }, { name: "Variant", labels: ["Opened", "Started", "Completed form", "Ordered", "Returned"], values: [100, 71, 52, 39, 29] }],
          Object.assign(chartBase(), { x: M + 0.25, y: Y0 + 0.7, w: lw - 0.5, h: CH - 0.9, barDir: "bar", barGrouping: "clustered", chartColors: ["A6A8A9", C.petrol], showValue: true, dataLabelPosition: "outEnd", showLegend: true, legendPos: "b", legendFontFace: F.body, legendFontSize: 10, catAxisOrientation: "maxMin", valAxisHidden: true, valGridLine: { style: "none" } }));
        card(s, rx, Y0, rw, chh);
        tx(s, "Weekly completion rate, %", { x: rx + P, y: Y0 + P - 0.05, w: rw - 2 * P, h: 0.3, fontSize: T.label, bold: true, color: C.text2 });
        s.addChart(pres.charts.LINE, [{ name: "Control", labels: ["W1", "W2", "W3", "W4"], values: [40, 41, 41, 42] }, { name: "Variant", labels: ["W1", "W2", "W3", "W4"], values: [43, 48, 51, 52] }],
          Object.assign(chartBase(), { x: rx + 0.2, y: Y0 + 0.7, w: rw - 0.4, h: chh - 0.85, chartColors: ["A6A8A9", C.petrol], lineSize: 2.5, lineDataSymbol: "circle", lineDataSymbolSize: 6, showLegend: false, valAxisMinVal: 35, valAxisMaxVal: 55 }));
        rr(s, rx, Y1 - ih, rw, ih, C.petrol, C.petrol, 0.12);
        tx(s, [{ text: "+11 pts at the form step. ", options: { bold: true } }, { text: lorem(10, 6) }], { x: rx + P, y: Y1 - ih, w: rw - 2 * P, h: ih, color: "FFFFFF", valign: "middle" });
      },
      resultsQual(s) {
        const th = [["Theme 1", "14 mentions"], ["Theme 2", "9 mentions"], ["Theme 3", "6 mentions"]];
        const cw = colW(3);
        th.forEach((t, i) => { const x = colX(i, 3), y = Y0; card(s, x, y, cw, CH);
          label(s, t[0].toUpperCase() + " · " + t[1], x + P, y + P, cw - 2 * P, C.dvText[i]);
          tx(s, cap(words(4, i * 6 + 2)), { x: x + P, y: y + 0.75, w: cw - 2 * P, h: 0.7, fontFace: F.disp, fontSize: 18, bold: true });
          [0, 1].forEach(j => { const qy = y + 1.6 + j * 1.35; rr(s, x + P, qy, cw - 2 * P, 1.2, C.sunken, C.sunken, 0.08);
            tile(s, "message", x + P + 0.15, qy + 0.15, 0.34);
            tx(s, "“" + lorem(8, i * 5 + j * 3 + 1, "") + ".”", { x: x + P + 0.62, y: qy + 0.14, w: cw - 2 * P - 0.8, h: 0.7, fontSize: T.label + 1 });
            tx(s, "Participant " + (i * 2 + j + 1) + " · Segment " + "ABC"[j + i > 2 ? 2 : j + i], { x: x + P + 0.62, y: qy + 0.86, w: cw - 2 * P - 0.8, h: 0.24, fontSize: T.label, color: C.text2 }); }); });
      },
      resultsMixed(s) {
        const lw = 5.6, rx = M + lw + G, rw = W - M - rx;
        card(s, M, Y0, lw, CH);
        label(s, "LOREM IPSUM RATE", M + P, Y0 + P, lw - 2 * P);
        tx(s, "+2.7 pts", { x: M + P, y: Y0 + 0.75, w: lw - 2 * P, h: 0.85, fontFace: F.disp, fontSize: T.display, bold: true, color: C.petrol });
        tx(s, "Variant 12.9% vs control 10.2% · p = 0.01", { x: M + P, y: Y0 + 1.65, w: lw - 2 * P, h: 0.3, fontSize: T.label, color: C.text2 });
        s.addChart(pres.charts.BAR, [{ name: "Rate", labels: ["Control", "Variant"], values: [10.2, 12.9] }],
          Object.assign(chartBase(), { dataLabelFormatCode: "0.0", x: M + 0.25, y: Y0 + 2.1, w: lw - 0.5, h: CH - 2.3, barDir: "bar", chartColors: [C.petrol], showValue: true, dataLabelPosition: "outEnd", showLegend: false, valAxisMinVal: 0, valAxisMaxVal: 15, barGapWidthPct: 90 }));
        rr(s, rx, Y0, rw, CH, C.surface, C.border, 0.12);
        tile(s, "message", rx + P, Y0 + P, 0.56);
        tx(s, "“" + lorem(18, 4, "") + ".”", { x: rx + P, y: Y0 + 1.2, w: rw - 2 * P, h: 1.9, fontFace: F.disp, fontSize: 19 });
        tx(s, [{ text: "Participant 7", options: { bold: true, breakLine: true } }, { text: "Segment B · variant group · interview", options: { color: C.text2, fontSize: T.label } }], { x: rx + P, y: Y1 - P - 0.6, w: rw - 2 * P, h: 0.6 });
      },
      twoCol(s) {
        const cw = colW(2), rx = colX(1, 2);
        card(s, M, Y0, cw, CH);
        label(s, "MESSAGE", M + P, Y0 + P, cw - 2 * P);
        tx(s, lorem(10, 7), { x: M + P, y: Y0 + 0.8, w: cw - 2 * P, h: 1.1, fontFace: F.disp, fontSize: 20, bold: true });
        tx(s, lorem(26, 15), { x: M + P, y: Y0 + 2.1, w: cw - 2 * P, h: CH - 2.1 - P, color: C.text2 });
        card(s, rx, Y0, cw, CH);
        label(s, "EVIDENCE", rx + P, Y0 + P, cw - 2 * P);
        s.addChart(pres.charts.BAR, [{ name: "Lorem", labels: ["Before", "After"], values: [34, 46] }],
          Object.assign(chartBase(), { x: rx + 0.25, y: Y0 + 0.8, w: cw - 0.5, h: CH - 1.6, barDir: "col", chartColors: [C.petrol], showValue: true, dataLabelPosition: "outEnd", showLegend: false, valAxisMinVal: 0, valAxisMaxVal: 60, barGapWidthPct: 100 }));
        tx(s, "Source: [placeholder] · method · n = 1,200", { x: rx + P, y: Y1 - P - 0.25, w: cw - 2 * P, h: 0.28, fontSize: T.label, color: C.text2 });
      },
      nextSteps(s) {
        const lw = 3.6;
        rr(s, M, Y0, lw, CH, C.inverse, C.inverse, 0.12);
        pill(s, "Decision needed", M + P, Y0 + P, 2.0, C.citron, C.inverse, 0.4);
        tx(s, lorem(7, 5), { x: M + P, y: Y0 + 1.05, w: lw - 2 * P, h: 1.4, fontFace: F.disp, fontSize: 20, bold: true, color: "FFFFFF" });
        tx(s, [{ text: "Scope: [lorem ipsum]", options: { breakLine: true } }, { text: "Owner: [role]", options: { breakLine: true } }, { text: "Resources: [dolor sit]" }], { x: M + P, y: Y0 + 2.75, w: lw - 2 * P, h: 1.3, color: C.onInverse, paraSpaceAfter: 8 });
        const hd = { bold: true, color: C.text2, fontSize: T.label, fill: { color: C.sunken }, fontFace: F.body };
        const cell = (t, o = {}) => ({ text: t, options: Object.assign({ fontSize: T.body, color: C.text, fontFace: F.body, fill: { color: C.surface } }, o) });
        const rows = [[{ text: "STEP", options: hd }, { text: "ACTION", options: hd }, { text: "OWNER", options: hd }, { text: "DATE", options: hd }]];
        ["Oct 2026", "Nov 2026", "Dec 2026", "Jan 2027", "Mar 2027"].forEach((d, i) => rows.push([cell(String(i + 1), { bold: true, color: C.petrol }), cell(cap(words(4, i * 4 + 3))), cell(["Leadership", "CX · Design", "Product · Eng", "CX · Ops", "Analytics"][i]), cell(d)]));
        const x0 = M + lw + G, tw = W - M - x0;
        s.addTable(rows, { x: x0, y: Y0, w: tw, colW: [0.9, tw - 0.9 - 2.1 - 1.3, 2.1, 1.3], rowH: [0.5, 0.79, 0.79, 0.79, 0.79, 0.79], border: { type: "solid", pt: 0.75, color: C.border }, valign: "middle", margin: [0, 0.2, 0, 0.2] });
      },
      persona(s) {
        const cw = colW(3);
        ["Segment A", "Segment B", "Segment C"].forEach((sg, i) => { const x = colX(i, 3), y = Y0; card(s, x, y, cw, CH);
          tile(s, "user", x + P, y + P, 0.64);
          tx(s, sg, { x: x + P + 0.82, y: y + P + 0.02, w: cw - 2 * P - 0.82, h: 0.34, fontFace: F.disp, fontSize: T.h4, bold: true });
          tx(s, ["Age 45–54 · lorem ipsum", "Age 55–64 · dolor sit", "Age 65–75 · amet elit"][i], { x: x + P + 0.82, y: y + P + 0.36, w: cw - 2 * P - 0.82, h: 0.28, fontSize: T.label, color: C.text2 });
          [["NEEDS", 1.25], ["BEHAVIORS", 2.35]].forEach(([lab, dy], j) => { label(s, lab, x + P, y + dy, cw - 2 * P);
            tx(s, [{ text: lorem(4, i * 5 + j * 3 + 2), options: { bullet: true, breakLine: true } }, { text: lorem(4, i * 5 + j * 3 + 9), options: { bullet: true } }], { x: x + P, y: y + dy + 0.32, w: cw - 2 * P, h: 0.65, fontSize: T.label + 1, paraSpaceAfter: 4 }); });
          const ty = y + CH - P - 0.45;
          rr(s, x + P, ty, cw - 2 * P, 0.45, C.sunken, C.sunken, 0.08);
          tx(s, "Top need: " + words(4, i * 7 + 3), { x: x + P + 0.15, y: ty, w: cw - 2 * P - 0.3, h: 0.45, fontSize: T.label + 0.5, bold: true, color: C.petrol, valign: "middle" }); });
      },
      quote(s) {
        const cw = colW(3);
        [0, 1, 2].forEach(i => { const x = colX(i, 3), y = Y0; card(s, x, y, cw, CH);
          tile(s, "message", x + P, y + P, 0.5);
          tx(s, "“" + lorem(15, i * 6 + 2, "") + ".”", { x: x + P, y: y + 1.1, w: cw - 2 * P, h: 1.5, fontFace: F.disp, fontSize: 16 });
          s.addShape(S.LINE, { x: x + P, y: y + 2.75, w: cw - 2 * P, h: 0, line: { color: C.border, width: 0.75 } });
          tx(s, "Segment " + "ABC"[i], { x: x + P, y: y + 2.9, w: cw - 2 * P, h: 0.32, fontFace: F.disp, fontSize: T.h4, bold: true });
          tx(s, "Age 45–64 · interview · " + ["2025", "2026", "2026"][i], { x: x + P, y: y + 3.24, w: cw - 2 * P, h: 0.28, fontSize: T.label, color: C.text2 });
          const ty = y + CH - P - 0.45;
          rr(s, x + P, ty, cw - 2 * P, 0.45, C.sunken, C.sunken, 0.08);
          tx(s, "Theme: " + words(3, i * 5 + 8), { x: x + P + 0.15, y: ty, w: cw - 2 * P - 0.3, h: 0.45, fontSize: T.label + 0.5, bold: true, color: C.petrol, valign: "middle" }); });
      },
      deviceHero(s) {
        pill(s, "[Concept name]", W - M - 2.4, 0.52, 2.4, C.citron, C.inverse, 0.36);
        const px = M + 0.7, pw = phone(s, "IPHONE-01", px, Y0, CH, "Product screen");
        const x = px + pw + 1.1;
        [0, 1, 2].forEach(i => callout(s, i + 1, cap(words(4, i * 5 + 3)), lorem(12, i * 6 + 5), x, Y0 + 0.4 + i * 1.4, W - M - x));
      },
      journeyStages(s) {
        STG.forEach((st, i) => { rr(s, sx(i), Y0, SW, 0.7, C.petrol, C.petrol, 0.08);
          tx(s, [{ text: st, options: { bold: true, breakLine: true } }, { text: words(3, i * 4 + 2), options: { fontSize: T.label, color: C.onPetrol } }], { x: sx(i) + 0.16, y: Y0, w: SW - 0.24, h: 0.7, color: "FFFFFF", fontSize: T.label + 1, valign: "middle" }); });
        const y1 = Y0 + 0.9, y2 = y1 + 1.2 + 0.2, y3 = y2 + 0.85 + 0.2, y4 = y3 + 0.5 + 0.2;
        rowLabel(s, "Customer goal", y1, 1.2); cells(s, y1, 1.2, C.surface, C.border, 2, 8);
        rowLabel(s, "Touchpoints", y2, 0.85);
        STG.forEach((_, i) => { rr(s, sx(i), y2, SW, 0.85, C.surface, C.border, 0.08); ["Email", "App", "Call"].slice(0, 1 + (i % 3)).forEach((t, j) => pill(s, t, sx(i) + 0.16 + j * 0.56, y2 + 0.27, 0.5, C.sunken, C.text2, 0.3)); });
        rowLabel(s, "Typical duration", y3, 0.5);
        ["1–2 days", "1 week", "2–3 days", "5–10 days", "1–2 weeks"].forEach((d, i) => { rr(s, sx(i), y3, SW, 0.5, C.sunken, C.sunken, 0.08); tx(s, d, { x: sx(i) + 0.16, y: y3, w: SW - 0.32, h: 0.5, bold: true, valign: "middle" }); });
        rowLabel(s, "Owner", y4, Y1 - y4);
        ["Marketing", "CX", "Clinical ops", "Logistics", "Lab · CX"].forEach((d, i) => { rr(s, sx(i), y4, SW, Y1 - y4, C.sunken, C.sunken, 0.08); tx(s, d, { x: sx(i) + 0.16, y: y4, w: SW - 0.32, h: Y1 - y4, color: C.text2, valign: "middle" }); });
      },
      journeyCurrent(s) {
        stageRow(s);
        const y1 = Y0 + 0.8, y2 = y1 + 1.05 + 0.2, y3 = y2 + 1.2 + 0.2;
        rowLabel(s, "What the customer does", y1, 1.05); cells(s, y1, 1.05, C.surface, C.border, 4);
        rowLabel(s, "How they feel", y2, 1.2); emotion(s, y2, 1.2, [0.55, 0.4, 0.1, 0.35, 0.5], ["Neutral", "Unsure", "Frustrated", "Hesitant", "Relieved"], C.errFg);
        rowLabel(s, "Pain points", y3, Y1 - y3); cells(s, y3, Y1 - y3, C.errBg, C.errBg, 11);
      },
      journeyFuture(s) {
        const ch = [["Email", C.dvText[0]], ["SMS", C.dvText[1]], ["RCS", C.dvText[2]], ["SMS", C.dvText[1]], ["Email", C.dvText[0]]];
        stageRow(s, ["T–45 days", "T–30 days", "T–0", "+3 to +10 days", "+14 days"], 0.7);
        const y1 = Y0 + 0.9, y2 = y1 + 0.45 + 0.2, y3 = y2 + 0.85 + 0.2, y4 = y3 + 1.0 + 0.2;
        rowLabel(s, "Channel moment", y1, 0.45);
        ch.forEach((c, i) => { rr(s, sx(i), y1, SW, 0.45, C.surface, c[1], 0.08, 1.25); oval(s, sx(i) + 0.16, y1 + 0.145, 0.16, c[1]);
          tx(s, [{ text: c[0] + "  ", options: { bold: true, color: c[1] } }, { text: words(2, i * 3 + 4) }], { x: sx(i) + 0.42, y: y1, w: SW - 0.5, h: 0.45, fontSize: T.label, valign: "middle" }); });
        rowLabel(s, "What the customer does", y2, 0.85); cells(s, y2, 0.85, C.surface, C.border, 6, 5);
        rowLabel(s, "How they feel", y3, 1.0); emotion(s, y3, 1.0, [0.6, 0.72, 0.85, 0.7, 0.9], ["Informed", "Ready", "In control", "Supported", "Reassured"], C.okFg);
        rowLabel(s, "What changes", y4, Y1 - y4); cells(s, y4, Y1 - y4, C.okBg, C.okBg, 14, 4);
      },
      messaging(s) {
        pill(s, "Restricted pattern · approval needed", W - M - 3.6, 0.52, 3.6, C.warnBg, C.warnFg, 0.34);
        const px = M + 0.7, pw = phone(s, "IPHONE-01", px, Y0, CH, "Message mockup");
        const x = px + pw + 1.1;
        label(s, "SMS · T–30 DAYS", x, Y0, W - M - x, C.dv[1]);
        [0, 1, 2].forEach(i => callout(s, i + 1, cap(words(3, i * 5 + 2)), lorem(12, i * 6 + 9), x, Y0 + 0.55 + i * 1.3, W - M - x, C.dv[1]));
        tx(s, "Message copy comes from the owner. Uses MSG-SMS-01 (proposed), which needs approval for each deck.", { x, y: 6.55, w: W - M - x, h: 0.3, fontSize: T.label, color: C.text2 });
      },
      deviceTrio(s) {
        const base = Y1 - 0.35, gap = 0.55;
        const ph = 3.1, pw = ph * 664 / 1328, th = 3.6, tw = th * 1803 / 2353, lw = 5.9, lh = lw * 1136 / 2016;
        const x1 = M + (CW - (pw + tw + lw + 2 * gap)) / 2, x2 = x1 + pw + gap, x3 = x2 + tw + gap;
        phone(s, "IPHONE-01", x1, base - ph, ph, "Phone"); phone(s, "IPAD-01", x2, base - th, th, "Tablet"); phone(s, "LAPTOP-01", x3, base - lh, lh, "Laptop");
        [["Phone", x1, pw], ["Tablet", x2, tw], ["Laptop", x3, lw]].forEach(([t, x, w]) => tx(s, t, { x, y: base + 0.12, w, h: 0.28, fontSize: T.label, bold: true, color: C.text2, align: "center" }));
        tx(s, lorem(14, 12), { x: M, y: 6.55, w: CW, h: 0.3, fontSize: T.label, color: C.text2 });
      },
    };

    /* ---------- title + how to use ---------- */
    const t = pres.addSlide(); t.background = { color: C.inverse };
    pill(t, "Template · lorem ipsum", M, 1.45, 2.5, C.citron, C.inverse, 0.4);
    tx(t, typeLabel, { x: M, y: 2.05, w: CW, h: 1.5, fontFace: F.disp, fontSize: 44, bold: true, color: "FFFFFF" });
    tx(t, lorem(14, 2), { x: M, y: 3.75, w: 8.2, h: 0.9, fontSize: 18, color: C.onPetrol });
    tx(t, `${deck.type} · ${deck.story}`, { x: M, y: 5.0, w: 8, h: 0.35, fontFace: F.mono, fontSize: 12, color: C.onPetrol });
    tx(t, "[Audience] · [Month Year] · Owner: [Name]", { x: M, y: 6.5, w: 8, h: 0.35, fontSize: T.body, color: C.onPetrol });

    const h = pres.addSlide(); h.background = { color: C.bg };
    header(h, "HOW TO USE THIS TEMPLATE", "Two ways to turn this template into your deck");
    footer(h, 2, "HOW-TO · delete before sharing");
    const hw = 5.2, ah = 2.0, by = Y0 + ah + G, bh = Y1 - by;
    card(h, M, Y0, hw, ah);
    label(h, "OPTION A · EDIT BY HAND", M + P, Y0 + 0.32, hw - 2 * P, C.petrol);
    tx(h, [{ text: "Replace every lorem ipsum line and dummy number with your content.", options: { bullet: true, breakLine: true } }, { text: "Keep the layouts. Delete slides you have no evidence for.", options: { bullet: true, breakLine: true } }, { text: "Put real screenshots behind the grey phone screens.", options: { bullet: true } }], { x: M + P, y: Y0 + 0.7, w: hw - 2 * P, h: 1.2, fontSize: T.body - 0.5, paraSpaceAfter: 4 });
    card(h, M, by, hw, bh);
    label(h, "OPTION B · USE CLAUDE", M + P, by + 0.32, hw - 2 * P, C.petrol);
    tx(h, "Attach the Storyloom spec, then write:", { x: M + P, y: by + 0.68, w: hw - 2 * P, h: 0.3 });
    rr(h, M + P, by + 1.08, hw - 2 * P, bh - 1.08 - 0.3, C.sunken, C.border, 0.08);
    tx(h, `Use ${deck.type} with ${deck.story}${deck.mode ? `, evidence mode ${deck.mode}` : ""}. Here is my objective, audience and data: …`, { x: M + P + 0.15, y: by + 1.08, w: hw - 2 * P - 0.3, h: bh - 1.08 - 0.3, fontFace: F.mono, fontSize: T.code, valign: "middle" });
    const lx = M + hw + 0.6, lw = W - M - lx;
    label(h, "SLIDE SEQUENCE IN THIS TEMPLATE", lx, Y0, lw);
    const rowH = Math.min(0.38, 3.75 / deck.slides.length);
    deck.slides.forEach((sl, i) => { const y = Y0 + 0.42 + i * rowH;
      tx(h, String(i + 3).padStart(2, "0"), { x: lx, y, w: 0.45, h: rowH, fontFace: F.mono, fontSize: T.code, color: C.text2, valign: "middle" });
      tx(h, sl[2], { x: lx + 0.5, y, w: lw - 3.1, h: rowH, fontSize: T.body - 1, valign: "middle" });
      tx(h, sl[1], { x: W - M - 2.55, y, w: 2.55, h: rowH, fontFace: F.mono, fontSize: T.code, color: C.petrol, align: "right", valign: "middle" });
      if (i < deck.slides.length - 1) h.addShape(S.LINE, { x: lx, y: y + rowH, w: lw, h: 0, line: { color: C.border, width: 0.5 } }); });
    tx(h, "All copy is lorem ipsum and every number is dummy data.", { x: lx, y: 6.55, w: lw, h: 0.28, fontSize: T.label, color: C.warnFg, bold: true });

    deck.slides.forEach((sl, i) => {
      const [r, id, purpose, o = {}] = sl;
      const title = o.hypothesis ? "Lorem ipsum hypothesis as one testable sentence" : lorem(6 + (i % 2), i * 3 + 1, "");
      const s = base(i + 3, purpose, id + (o.ids ? " · " + o.ids : ""), title);
      R[r](s, Object.assign({ seed: i }, o));
    });
    return { pres, deck };
  }

  const API = { DECKS, FRAMES, ICON_NAMES, ICON_COLORS, build };
  if (typeof module !== "undefined" && module.exports) module.exports = API; else root.CXDeck = API;
})(typeof window !== "undefined" ? window : this);
