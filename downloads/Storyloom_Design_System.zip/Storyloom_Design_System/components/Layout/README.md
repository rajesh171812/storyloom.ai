Four small layout helpers built on the spacing and layout tokens: a centered container, a responsive column grid, a vertical stack and a wrapping cluster.

```
Component:  Layout
Purpose:    Arrange content without one-off spacing.
Classes:    bl-container | bl-grid | bl-stack | bl-cluster | bl-sr-only
Grid:       4 columns under 768px, 8 from 768px, 12 from 1024px (--grid-columns). Margin and gutter follow: 16 / 24 / 32 and 16 / 24 / 24.
Rules:      Page max 1440px, content container 1200px (--layout-container-max) plus the page margin on each side.
            Multi-column content stacks in reading order below 768px. Never hide the primary action, an error or task-critical
            information at any width; move it instead.
            Set --stack-gap or --cluster-gap on the element to change the gap; otherwise stack uses space-4 and cluster space-3.
A11y:       bl-sr-only hides text visually but keeps it for screen readers (skip links, extra context for icon-only controls).
Code:       <main class="bl-container"><div class="bl-grid">...</div></main>
```

Breakpoints are literal in `@media` rules (`768px`, `1024px`, `1440px`), because CSS variables cannot be used there.
