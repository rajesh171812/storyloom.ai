A small pill for the status of an item, in a neutral, success, warning, error, info or accent tone.

```
Component:  Badge
Purpose:    Show the status of an item.
Variants:   default | success | warning | error | info | accent
Rules:      A status badge always has an icon or a word, never color alone. Sentence case.
            Use bl-tag, not a badge, for labels people add and can remove.
            The accent badge (lavender) is for rare highlights such as "New".
A11y:       Text meets 4.5:1 on its tinted fill in both themes (status-*-fg on status-*-bg; accent-text on accent-bg).
Code:       <span class="bl-badge bl-badge--success"><svg class="bl-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>Paid</span>
```

The icon inside a badge is drawn at 12px automatically. The pill is 24px tall with a 1px border in the tone's border color.
