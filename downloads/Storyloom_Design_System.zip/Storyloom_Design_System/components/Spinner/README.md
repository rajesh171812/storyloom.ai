A rotating ring in `currentColor`, 20px by default and 16px small, for a short wait of unknown length.

```
Component:  Spinner
Purpose:    Show that something is loading when the wait is short and its length unknown.
Sizes:      bl-spinner (icon-md 20) | bl-spinner--sm (icon-sm 16)
Rules:      Always pair the spinner with a text label ("Loading invoices"). In a button, use bl-spinner--sm, set aria-busy="true"
            and keep the button width and focus. Use bl-skeleton when the layout is known and bl-progress when the length is known.
A11y:       The ring is decorative (aria-hidden="true"); put role="status" on the container that holds the label.
            Under prefers-reduced-motion it stops rotating and becomes a dotted ring.
Code:       <div role="status"><span class="bl-spinner" aria-hidden="true"></span> Loading invoices</div>
```
