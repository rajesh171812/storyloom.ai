A checkbox styled as a 40 by 24 toggle for settings that take effect the moment they change.

```
Component:  Switch
Purpose:    Turn a setting on or off immediately.
Parts:      label.bl-switch > input[type=checkbox][role=switch] + span.bl-switch__track + span (label text)
States:     off, on, hover, focus, disabled
Rules:      Use when the change applies immediately; use bl-check when the choice needs a Save button.
            The label stays visible next to the toggle and is part of the click target.
A11y:       role="switch" on a native checkbox; the thumb moves and the track fills, so state never relies on color alone.
            2px focus ring on the track.
Code:       <label class="bl-switch"><input type="checkbox" role="switch"><span class="bl-switch__track"></span><span>Email notifications</span></label>
```
