A labelled text control: field wrapper, persistent label, optional help text, single-line input or textarea, and an error line with icon and text.

```
Component:  TextField
Purpose:    Collect free text, an email address, a search term or a longer message.
Parts:      bl-field > label.bl-label + p.bl-help (optional) + input.bl-input | textarea.bl-textarea + p.bl-error (when invalid)
            bl-input-wrap adds a leading icon and an optional clear button (bl-input-clear)
States:     default, hover, focus, disabled, read-only, invalid
Sizes:      Input min-height 40 (44 on touch); textarea min-height 96, resizable vertically. Text is 16px so mobile browsers do not zoom.
Rules:      Every input has a visible, persistent <label>. Placeholders are examples, not labels. Mark optional fields "(optional)"
            (bl-label__opt); never use an asterisk alone. One column. Set type and autocomplete correctly.
            Validate on blur (format) and on submit (completeness). Do not clear the input after an error.
            Errors have an icon and text, never color alone.
A11y:       On submit with errors show an error summary (role="alert"), set aria-invalid="true" and aria-describedby on each invalid input,
            and move focus to the first invalid field. Focus shows a 2px ring in color-border-focus.
Code:       <div class="bl-field"><label class="bl-label" for="email">Email address</label>
              <input class="bl-input" id="email" type="email" autocomplete="email"></div>
```

An invalid input gets a 2px `color-status-error-solid` border. The error text follows the input inside the same `bl-field` and is referenced by `aria-describedby`. Error copy says what happened and how to fix it: "Enter an email address like name@example.com."
