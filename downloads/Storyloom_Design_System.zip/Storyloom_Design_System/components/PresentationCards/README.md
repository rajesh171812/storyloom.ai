The card family CX slides are assembled from: KPI with delta, insight, quote with attribution, evidence with source, and the lavender highlight.

```
Component:  PresentationCards
Purpose:    Carry one number, one finding, one quote or one proof point per card.
Parts:      .cx-kpi (.cx-eyebrow, .cx-kpi__value, .cx-delta[--down], .cx-kpi__note)  = CMP-KPI-01 / CMP-METRIC-01
            .cx-insight (.cx-eyebrow, .cx-insight__text)                            = CMP-INSIGHT-01
            .cx-quote (.cx-icon-tile, .cx-quote__text, .cx-quote__who > span)      = CMP-QUOTE-01 + CMP-CUSTOMER-01
            .cx-evidence (.cx-evidence__value, text, .cx-evidence__source)          = CMP-EVIDENCE-01
            .cx-highlight                                                            = the one lavender highlight per slide
Rules:      One message per card. A delta always has an icon and a direction word ("Up", "Down (better)").
            Quotes are verbatim and attributed to a segment, never invented; placeholders say so.
            Every number shows its source, method and sample size on the same slide.
            Use lavender (.cx-highlight) at most once per slide.
A11y:       Values are text, not images. Delta colors pair with an icon and a word. Insight text is 15:1 on Deep navy.
```
