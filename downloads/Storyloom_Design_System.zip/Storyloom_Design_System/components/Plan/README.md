A list of steps an AI feature is taking, each with a state marker, a description and a trailing status or action, including a step that needs approval.

```
Component:  Plan
Purpose:    Show what an AI feature will do or is doing, and hold risky steps for approval.
Parts:      ol.bl-plan > li[data-state] > span.bl-plan__state + description + trailing status or buttons
States:     pending (default), running, done, needs-approval
Rules:      Any action that sends, spends, deletes or shares requires a preview and explicit approval, and is recorded in a
            reviewable history. Give a needs-approval step a warning border (2px) and Approve and Review buttons.
            A done step shows a check in a success-colored circle; a running step shows a small spinner.
A11y:       Each state also has a word or icon (badge "Done", "Running", a check, a spinner), never color alone.
            Announce a step change once when it happens rather than continuously.
Code:       <ol class="bl-plan"><li data-state="needs-approval"><span class="bl-plan__state"></span><span>Send 3 reminders</span>
              <button class="bl-btn bl-btn--primary bl-btn--sm">Approve</button></li></ol>
```
