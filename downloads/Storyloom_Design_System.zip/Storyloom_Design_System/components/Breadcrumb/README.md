A wrapping list of links separated by slashes, ending in the current page.

```
Component:  Breadcrumb
Purpose:    Show where the page sits in the hierarchy and let people go up a level.
Parts:      nav.bl-breadcrumb[aria-label="Breadcrumb"] > ol > li > a ; the last li has aria-current="page"
Rules:      The current page is not a link and is set in color-text-primary at medium weight.
            Ancestors are links in color-text-link; the slash separators are decorative and added by CSS.
A11y:       Wrap in a nav with aria-label="Breadcrumb" and use an ordered list. Mark the last item aria-current="page".
Code:       <nav class="bl-breadcrumb" aria-label="Breadcrumb"><ol><li><a href="/projects">Projects</a></li><li aria-current="page">Invoices</li></ol></nav>
```
