A native checkbox drawn with a 20px token-styled box, for on/off choices that are saved later and for multi-select lists.

```
Component:  Checkbox
Purpose:    Let people select zero or more options, or set an on/off value that needs a Save button.
Parts:      label.bl-check > input[type=checkbox] + span.bl-check__box + span (label text)
States:     unchecked, checked, indeterminate, hover, focus, disabled, invalid
Rules:      Use for on/off that needs a Save button; use bl-switch when the change applies immediately.
            The label text is always visible and part of the click target.
            Invalid: set aria-invalid="true" on the label (styling hook) and on the input, and show an error line with icon and text.
A11y:       Native input (24px hit area), 2px focus ring on the box, checked state shows a check mark and not color alone.
            Set indeterminate with JavaScript (input.indeterminate = true) for a partly selected group.
Code:       <label class="bl-check"><input type="checkbox"><span class="bl-check__box"></span><span>Email me receipts</span></label>
```
