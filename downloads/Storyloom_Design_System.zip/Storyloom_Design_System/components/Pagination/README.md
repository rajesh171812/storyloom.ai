A row of ghost buttons for moving through pages of results, with the current page filled in the primary color.

```
Component:  Pagination
Purpose:    Move between pages of a long list or table.
Parts:      nav.bl-pagination > button.bl-btn.bl-btn--ghost (page, previous, next) ; the current page has aria-current="page"
Rules:      Use ghost buttons for page links and icon-only ghost buttons for previous and next. Disable previous on the first page
            and next on the last. Buttons are at least as wide as they are tall (min-width = button height).
A11y:       Wrap in a nav with aria-label="Pagination". Give every button an accessible name ("Page 3", "Previous page"),
            and mark the current page with aria-current="page". The current page is filled, so it never relies on color alone.
Code:       <nav class="bl-pagination" aria-label="Pagination"><button class="bl-btn bl-btn--ghost" aria-current="page" aria-label="Page 3, current page">3</button></nav>
```
