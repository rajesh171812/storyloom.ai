A short inverse-colored hint that appears above its trigger on hover or keyboard focus.

```
Component:  Tooltip
Purpose:    Name or briefly explain a control.
Parts:      span.bl-tooltip-wrap > trigger + span.bl-tooltip[role=tooltip]
Rules:      Keep it to a phrase (max width 240px). Never put essential information, an error or the only label of a control in a tooltip.
            Fill color-surface-inverse, text color-text-inverse, shadow-2, z-index --z-tooltip (600).
A11y:       The trigger references the tooltip with aria-describedby. It opens on hover and on focus-within; bl-tooltip.is-open
            forces it visible for documentation. Icon-only triggers still need their own aria-label.
Code:       <span class="bl-tooltip-wrap"><button class="bl-btn bl-btn--secondary bl-btn--icon" aria-label="Help" aria-describedby="tt">...</button>
              <span class="bl-tooltip" role="tooltip" id="tt">Archived projects stay searchable</span></span>
```
