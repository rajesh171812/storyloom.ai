A row of equal steps with a 4px bar above each, a numbered or checked dot and a label, showing where a person is in a multi-step task.

```
Component:  Stepper
Purpose:    Show progress through a fixed sequence of steps.
Parts:      ol.bl-stepper > li.bl-step > span.bl-step__label > span.bl-step__dot + text
States:     upcoming (default), complete (data-state="complete", check icon in the dot), current (aria-current="step")
Rules:      Completed steps show a check icon and current step is bold, so state never relies on color alone.
            Keep labels short, in sentence case.
A11y:       Use an ordered list with aria-label, mark the current step with aria-current="step", and add visually hidden text
            (bl-sr-only) such as "Completed:" for finished steps.
Code:       <ol class="bl-stepper" aria-label="Checkout"><li class="bl-step" aria-current="step"><span class="bl-step__label"><span class="bl-step__dot">2</span>Payment</span></li></ol>
```
