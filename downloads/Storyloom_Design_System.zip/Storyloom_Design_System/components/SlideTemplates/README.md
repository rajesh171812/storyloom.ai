The governed 16:9 slide layouts. Each has an SLD-* ID, a status and the components it is built from; the full list, wireframes and template decks are in Storyloom AI Presentation spec and site.

```
Component:  SlideTemplates
Purpose:    Lay out one message per slide on a 1280 × 720 canvas (13.333 × 7.5 in).
Parts:      .cx-slide[--title] > .cx-slide__kicker + .cx-slide__title + body built from PresentationCards, JourneyMap, DeviceFrames
Templates:  24 approved or conditional SLD-* layouts: title, section, executive summary, statement, KPI grid, KPI + trend,
            chart focus, insight + evidence, quote, persona, 2- and 3-column, before/after, variants, journey, process,
            timeline, priority matrix, device hero, cross-device, messaging (Restricted), recommendations, next steps, bullet list.
Rules:      Title and section slides sit on Deep navy; content slides on the page ground. Titles state the takeaway.
            Slide margin 48px (space-8), card padding 24px, gaps 16px. Lavender once per slide.
            Type (canvas px): title 40/48 Bricolage 700, KPI 56/60, card title 20/28, body 18/28 Hanken, source 14/20 minimum.
            Icons use the Rounded tile. Every claim shows its evidence on the slide.
A11y:       Text 4.5:1 on its ground; charts are native and direct-labelled; each slide reads without color.
```
