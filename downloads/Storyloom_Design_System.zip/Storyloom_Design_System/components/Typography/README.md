Type utilities that apply the Storyloom Design System scale: display, headings, body sizes, caption, secondary text, inline code, links and the prose measure.

```
Component:  Typography
Purpose:    Apply the type scale to text without inventing sizes.
Classes:    bl-display | bl-h1 | bl-h2 | bl-h3 | bl-h4 | bl-body-lg | bl-body-sm | bl-caption
            bl-text-secondary | bl-prose | bl-code | bl-link | bl-body (on <body>)
Rules:      One h1 per page; never skip heading levels. Restyle with .bl-h1 to .bl-h4 instead of picking a heading tag for its size.
            Headings use Bricolage Grotesque (display family), text Hanken Grotesk (sans), code IBM Plex Mono (mono).
            Sentence case everywhere. Body text lines stay under 68ch: wrap paragraphs in bl-prose.
            Secondary text is color-text-secondary; never use color-text-disabled for text people must read.
Responsive: Display, h1, h2 and h3 shrink below 768px through the font shorthand tokens; nothing else changes.
A11y:       Links are always underlined and change thickness on hover, so they never rely on color alone. Contrast 4.5:1 or more.
Code:       <body class="bl-body"><h1 class="bl-h1">Project overview</h1><p class="bl-prose">...</p></body>
```

Set `class="bl-body"` on `<body>` for the page background, text color and the default `font-body` style. Use `font: var(--font-body); letter-spacing: var(--letter-spacing-body);` when a component needs the same style. `bl-display` is for the marketing hero only.
