Transparent device frames with measured screen areas. The real screenshot goes underneath and fills the screen area exactly. Files are in the asset group *Device frames*.

```
Component:  DeviceFrames
Purpose:    Show a real product screen in context on a slide or page.
Parts:      .cx-device (width set; --x --y --w --h = screen area in % of the frame) > .cx-device__screen (the screenshot) + img (the frame)
Frames:     DEVICE-IPHONE-01 iPhone 15 Pro 664×1328 [4.97, 2.18, 90.21, 95.63]   Approved, default mobile
            DEVICE-IPHONE-02 iPhone notch 600×1210 [6.0, 2.56, 88.17, 94.88]      Conditional: notch-era captures, RCS
            DEVICE-IPAD-01 iPad portrait 1803×2353 [4.22, 3.27, 91.51, 93.54]     Approved
            DEVICE-IPAD-02 iPad landscape 2352×1803 [3.15, 4.1, 93.62, 91.63]     Approved
            DEVICE-LAPTOP-01 MacBook Air 2016×1136 [12.3, 5.81, 75.5, 84.15]      Approved
            DEVICE-BROWSER-01 Browser 3084×1962 [3.31, 10.7, 93.39, 81.55]        Approved
            DEVICE-DESKTOP-01 Monitor draft 1600×1156 [2.25, 3.11, 95.5, 73.7]    Restricted: approval per use
Rules:      Real screenshots only; never redraw product UI inside a frame. One frame family per slide.
            Front-facing, never stretched, no added tilt or shadow. Same product on several slides: same frame.
A11y:       The frame image is decorative (alt=""); the screenshot carries the alt text.
```
