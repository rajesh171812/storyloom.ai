A horizontal tab list with a 2px underline on the selected tab, for switching between views of the same content.

```
Component:  Tabs
Purpose:    Switch between sibling views in the same place.
Parts:      .bl-tabs[role=tablist] > button.bl-tab[role=tab][aria-selected] ; panels with role="tabpanel"
States:     default, hover, selected (aria-selected="true"), focus
Rules:      Tab labels are in sentence case and name the view. Tab height is 44px, so the target is large enough for touch.
            The list scrolls horizontally when it does not fit; never hide a tab a person needs.
A11y:       Set aria-selected on the current tab, link each tab to its panel with aria-controls, and give the list an aria-label.
            The selected tab is bold with a primary underline, so selection never relies on color alone.
Code:       <div class="bl-tabs" role="tablist" aria-label="Project"><button class="bl-tab" role="tab" aria-selected="true">Overview</button>...</div>
```

State is carried by `aria-selected`, not by a class. `bl-tab.is-hover` exists only for documentation.
