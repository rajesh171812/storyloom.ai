A circular avatar showing initials on the selected-state fill, in small, default and large sizes.

```
Component:  Avatar
Purpose:    Identify a person or account compactly.
Sizes:      bl-avatar--sm 24 | default 40 | bl-avatar--lg 48
Rules:      Show initials. Give the avatar an accessible name (role="img" with aria-label) unless the name appears next to it.
            The fill is color-state-selected-bg with a 1px color-state-selected-border; text is color-text-primary.
A11y:       Initials are text, not an image, so they scale with zoom. Decorative avatars next to a name use aria-hidden="true".
Code:       <span class="bl-avatar" role="img" aria-label="Ana Ruiz">AR</span>
```

Text size scales with the avatar (36% of its width). An image can be placed inside; the circle clips it.
