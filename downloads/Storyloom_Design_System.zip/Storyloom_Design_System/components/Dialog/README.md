A modal surface with a 16px radius, shadow-3 and a scrim behind it, for confirming an irreversible action or a focused task.

```
Component:  Dialog
Purpose:    Confirm an irreversible action, or hold a short focused task.
Parts:      dialog.bl-dialog > h2.bl-dialog__title + p.bl-dialog__body + .bl-dialog__actions
            The backdrop is dialog::backdrop in color-overlay-scrim; .bl-scrim paints the same surface for documentation.
Rules:      Use a dialog for an irreversible action. Title = action + object ("Delete project?"), body = the consequence,
            buttons repeat the verb ("Delete project" / "Keep project"). Destructive is never the default focus.
Responsive: Spec: mobile is a full-width bottom sheet; tablet and desktop a centered dialog, max 480px. components.css centers the dialog
            at every width (width min(480px, 100%)), so a bottom sheet on mobile needs a layout override.
A11y:       Use a native <dialog> opened with showModal() so focus is trapped and Escape closes it; set aria-labelledby to the title
            and aria-describedby to the body.
Code:       <dialog class="bl-dialog" aria-labelledby="t"><h2 class="bl-dialog__title" id="t">Delete project?</h2>
              <p class="bl-dialog__body">This permanently deletes the project and its 12 tasks.</p>
              <div class="bl-dialog__actions"><button class="bl-btn bl-btn--secondary" autofocus>Keep project</button>
              <button class="bl-btn bl-btn--destructive">Delete project</button></div></dialog>
```
