A journey grid: stages across the top, rows for what the customer does, how they feel, pain points or what changes. CMP-JOURNEY-01 / SLD-JOURNEY-01.

```
Component:  JourneyMap
Purpose:    Show an experience across customer stages, current or future state.
Parts:      .cx-journey (set --cx-stages, default 5) > .cx-journey__label + .cx-journey__stage + .cx-journey__cell[--pain | --gain]
Rules:      3 to 6 stages; the same stage names on the current- and future-state slides.
            Pain cells use the error tint, change cells the success tint; the row label says which, so color is never alone.
            A feeling row, when used, is a line through one dot per stage with a word under each dot.
Responsive: Below 768px scroll the grid horizontally in its own container rather than squeezing cells.
A11y:       Read row by row: give each row a text label. Keep cell text to one short sentence.
```
