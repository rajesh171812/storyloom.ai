Triggers an action within a workflow: five variants, three sizes, and every state rendered from tokens.

```
Component:  Button
Purpose:    Trigger an action within a workflow.
Variants:   primary | secondary | tertiary | ghost | destructive
Sizes:      sm (32) | md (40, default) | lg (48); on touch devices (pointer: coarse) sm 40 | md 44 | lg 52
States:     default, hover, pressed, focus, disabled, loading
Rules:      One primary per section. Label = verb + object ("Create account", "Send invoice"), never "Submit" or "OK".
            Destructive only for deleting or irreversible actions, and never the default focus in a confirmation dialog.
            Loading keeps the width and the focus, sets aria-busy="true" and shows bl-spinner bl-spinner--sm.
            Icon-only buttons (bl-btn--icon) require aria-label.
Responsive: A lone primary is full width below 768px (bl-btn--block); a stacked pair is full width too.
A11y:       Native <button>; 2px focus ring in color-border-focus; 4.5:1 label contrast in both themes.
Code:       <button class="bl-btn bl-btn--primary" type="button">Create account</button>
```

The consumer provides the label text and, for icon buttons, an inline `bl-icon` SVG (icon first, then the label). Add `bl-btn--sm` or `bl-btn--lg` for the other sizes and `bl-btn--block` for full width. Disable with the `disabled` or `aria-disabled="true"` attribute, not a class.

The `is-hover`, `is-active` and `is-focus` classes exist only so documentation can show every state at once; do not use them in product code.

`window.Storyloom.Button` is the reference React wrapper: `<Button variant="primary" icon={<Plus className="bl-icon" aria-hidden />}>New project</Button>`. It warns when an icon-only button has no `aria-label`.
