An inline message tied to a place on the page, with a status icon, a title, a body, optional actions and an optional dismiss button.

```
Component:  Alert
Purpose:    Give feedback about the content next to it, or about page-wide or account-wide state (banner).
Variants:   info (default) | bl-alert--success | bl-alert--warning | bl-alert--error | bl-alert--banner (full-bleed, no side borders)
Parts:      .bl-alert > svg.bl-icon + div(.bl-alert__title, .bl-alert__body, .bl-alert__actions) + dismiss button (optional)
Rules:      Use an alert for a message tied to a place on the page; a banner for page-wide or account-wide state;
            a toast for confirmation of an action just taken. Never use color alone: every tone has an icon and a title.
            Errors state what happened and how to fix it, without apologizing or blaming.
            Not "Something went wrong." but "We couldn't save your changes. Check your connection and try again."
A11y:       The title uses status-*-fg on status-*-bg (4.5:1 or more in both themes); the icon uses status-*-solid (3:1 or more).
            Give a dismiss button an aria-label. The error summary on a form uses role="alert".
Code:       <div class="bl-alert bl-alert--error" role="alert"><svg class="bl-icon" viewBox="0 0 24 24" aria-hidden="true">...</svg>
              <div><p class="bl-alert__title">Payment failed</p><p class="bl-alert__body">...</p></div></div>
```
