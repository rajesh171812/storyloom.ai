An 8px pill-shaped bar whose fill width shows how far a task of known length has progressed.

```
Component:  Progress
Purpose:    Show progress when the length of the wait is known.
Parts:      .bl-progress[role=progressbar] > span (style="width: N%")
Rules:      Use for a wait of known length; use bl-spinner for a short wait of unknown length and bl-skeleton when the layout is known.
            Show the value or a label next to the bar so progress never relies on the fill alone.
A11y:       role="progressbar" with aria-valuemin, aria-valuemax, aria-valuenow and a name via aria-labelledby.
            The fill animates over duration-slow and stops under prefers-reduced-motion.
Code:       <div class="bl-progress" role="progressbar" aria-label="Upload" aria-valuemin="0" aria-valuemax="100" aria-valuenow="64"><span style="width:64%"></span></div>
```
