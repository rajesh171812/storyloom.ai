Inline SVG icons drawn as Lucide outlines, stroked with `currentColor` at `--icon-stroke` and sized with one class.

```
Component:  Icon
Purpose:    Reinforce a label or action with a small symbol.
Sizes:      bl-icon--xs 12 | bl-icon--sm 16 | bl-icon (md, 20, default) | bl-icon--lg 24 | bl-icon--xl 32
States:     Inherits color from its parent (currentColor); no states of its own.
Rules:      Use Lucide outline icons only, inline as SVG with viewBox="0 0 24 24". Never rely on an icon alone to carry meaning:
            errors have an icon and text, status badges an icon or a word.
            Icon-only buttons need aria-label on the button.
A11y:       Decorative icons carry aria-hidden="true". A standalone informative icon gets role="img" and aria-label.
Code:       <svg class="bl-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
```

Inside a small button, a badge, an error message or a stepper dot the icon size steps down automatically (`sm`, `xs`), so do not add a size class there. Change an icon's color by setting `color` on its container, using a semantic token.
