# AI features in the product

- Label generated content ("AI-generated"), using `bl-ai-msg__who` with a badge.
- Show sources with numbered citations (`bl-cite`, `bl-source`) and say what data was used.
- Make output editable, rejectable, regenerable and undoable, with a Stop control while the AI is working.
- Any action that sends, spends, deletes or shares requires a preview and explicit approval, and is recorded in a reviewable history. Show pending approvals in `bl-plan` with a `needs-approval` step.
- Errors and refusals say what could not be done and what to try.
- Do not announce streaming text token by token to screen readers; announce start and completion.
- Components: `bl-prompt` (Prompt), `bl-ai-msg` (AiMessage), `bl-cite` and `bl-source` (in AiMessage), `bl-plan` (Plan), `bl-stream-cursor` (in AiMessage).
