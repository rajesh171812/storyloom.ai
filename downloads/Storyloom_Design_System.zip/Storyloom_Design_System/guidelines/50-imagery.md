# Imagery

Every photograph in Storyloom Design System prints in pure black and white. Color stays with the interface — buttons, badges, the accent square — never the picture.

```html
<div class="bl-photo-frame" style="aspect-ratio: 4 / 3">
  <img class="bl-photo" src="photo.jpg" alt="Describe what the photo shows and why it's here">
</div>
```

- `bl-photo-frame` is the crop container: give it a fixed `aspect-ratio` (or an explicit height) and it clips to `overflow: hidden`.
- `bl-photo` applies `grayscale(1)` and `object-fit: cover`. It never ships its own color filter, tint or duotone; propose a new class instead of changing this one if a tinted treatment is needed later.
- Alt text is required. A purely decorative photo (a background behind a scrim, for instance) gets `alt=""` with `role="presentation"` instead of a description, so screen readers skip it.

## Crops

Match the ratio to the slot; don't stretch or letterbox a photo to a ratio it wasn't shot for — recrop it instead.

| Ratio | Use |
|---|---|
| 16:9 | Full-bleed sections, wide hero photos |
| 4:3 | Framed images, feature photos |
| 3:4 | Portrait hero columns |
| 1:1 | Avatars, small supporting images (`bl-avatar`) |

## The scrim

`bl-scrim-photo` is a gradient overlay for when text sits on top of a photo. It fades from `color-background-default` at the top and bottom to transparent in the middle, so the gradient is always the current theme's ground color, not a fixed black or white wash — this is what keeps text readable over a photo without leaving the token palette or breaking dark mode.

```html
<div class="bl-photo-frame">
  <img class="bl-photo" src="photo.jpg" alt="">
  <div class="bl-scrim-photo" aria-hidden="true"></div>
</div>
```

Only use the scrim where text overlaps the photo. A framed or half-bleed image with copy beside it, not on top of it, doesn't need one.

## Rules

- [ ] No color photography, no duotone, no sepia. Grayscale only.
- [ ] No text directly on a photograph without a scrim behind it, and check the resulting contrast — a scrim is a gradient, not a guarantee.
- [ ] Every photo has `alt` text describing its content, or `alt=""` plus `role="presentation"` if it's decorative.
- [ ] Cropped to one of the four ratios above; the source image is never distorted.
- [ ] A caption, when present, sits outside the photo frame or in the scrim area — never as a floating label with no background.

See the Photography component for a live example, and the Templates component for how the same treatment carries into a full deck or landing page.
