# Storytelling

Rules every CX deck is checked against before the final review.

1. One primary message per slide.
2. Lead with the insight, not the artifact.
3. Every claim is backed by evidence on the slide.
4. Cut slides that exist only to fill a template.
5. Never repeat the same information on two slides.
6. Progress: context, understanding, evidence, implication, action.
7. Use a visual when it communicates faster than text.
8. Use a chart only when it reveals a meaningful pattern.
9. No decorative visualizations.
10. Keep hierarchy, spacing, type and visual language consistent.
11. Use the same approved representation for the same thing throughout.
12. Show native experiences with their approved pattern, never a generic placeholder.
13. Visual design never changes the approved story.

Content hierarchy on every slide: primary message → supporting evidence → context → implication. Never equal visual weight.

Story structures: default CX (context → problem → insight → evidence → opportunity → solution → impact → action), performance, experiment, concept, journey, and executive answer-first (5 slides or fewer).
